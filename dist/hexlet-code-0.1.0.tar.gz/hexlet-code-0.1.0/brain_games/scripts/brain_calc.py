#!/usr/bin/env python
from brain_games.engine import greeting

import brain_games.games.calc


def main():
    greeting(brain_games.games.calc)


if __name__ == "__main__":
    main()
