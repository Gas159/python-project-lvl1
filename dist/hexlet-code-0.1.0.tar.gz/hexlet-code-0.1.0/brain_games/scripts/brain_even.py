#!/usr/bin/env python

from brain_games.even_games import is_even


def greet():
    print("Welcome to the Brain Games!")


def main():
    greet()
    is_even()


if __name__ == "__main__":
    main()
