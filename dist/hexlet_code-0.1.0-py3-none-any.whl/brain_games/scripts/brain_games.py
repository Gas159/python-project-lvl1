#!/usr/bin/env python

def greet ():
	print("Welcome to the Brain Games!")

def main():
	greet()

if __name__ == "__main__":
	main()

