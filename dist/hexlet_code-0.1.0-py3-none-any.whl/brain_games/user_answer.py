

def user_answer():
    if user_answer == true_answer:
        print("Correct!")
    else:
        return print(
            f"'{user_answer}' is wrong answer ;(."
            f" Correct answer was '{true_answer}'."
            f"\nLet's try again, {name}!")
